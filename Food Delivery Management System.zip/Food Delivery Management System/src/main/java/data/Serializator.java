package data;

import business.DeliveryService;

import java.io.*;

public class Serializator {

    public static void serialize(DeliveryService deliveryService){
        try{
            FileOutputStream output = new FileOutputStream("information.txt");
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(output);
            objectOutputStream.writeObject(deliveryService);
            objectOutputStream.close();
            output.close();
            System.out.println("Serialized data is saved in information.txt");

        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static DeliveryService deserialize(){

        DeliveryService deliveryService = null;
        try{

            FileInputStream fileInputStream = new FileInputStream("information.txt");
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);
            deliveryService = (DeliveryService) objectInputStream.readObject();
            objectInputStream.close();
            fileInputStream.close();
            return deliveryService;

        } catch (IOException exception) {
            System.out.println(exception);
            deliveryService = new DeliveryService();
            serialize(deliveryService);
            return deliveryService;
        }catch (ClassNotFoundException c){
            System.out.println("DeliveryService class not found");
            c.printStackTrace();
            return deliveryService = new DeliveryService();
        }
    }

}
