package data;

import business.MenuItem;
import business.Order;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.ArrayList;

public class FileWriter {

    private float price2 = 0;

    public FileWriter() {

    }

    public void setPrice2(float pr) {
        this.price2 = price2 + pr;
    }


    public void writeInFile(Order O, ArrayList<MenuItem> list) throws IOException {

        StringBuilder stringBuilder = new StringBuilder();
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("bill.txt")));
        stringBuilder.append(O.toString());
        list.stream().forEach(s->{
            setPrice2(s.getPrice());
            stringBuilder.append(s.toString() + " ");
        });
        stringBuilder.append("\n");
        stringBuilder.append("ORDER PRICE: " + price2 + "\n");
        bufferedWriter.write(stringBuilder.toString());
        bufferedWriter.close();


    }
}
