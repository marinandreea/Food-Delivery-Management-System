package business;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Order {

    private int orderID;
    private int clientID;
    private LocalDateTime date;

    public Order(int orderID, int clientID, LocalDateTime date) {
        this.orderID = orderID;
        this.clientID = clientID;
        this.date = date;
    }

    public int getOrderID() {
        return orderID;
    }

    public void setOrderID(int orderID) {
        this.orderID = orderID;
    }

    public LocalDateTime getDate() {
        return date;
    }

    public void setDate(LocalDateTime date) {
        this.date = date;
    }

    @Override
    public int hashCode(){

        int hashcode = 11;
        hashcode = hashcode * 7 + 31 * orderID + 5 * clientID;
        return hashcode;
    }

    @Override
    public boolean equals(Object obj){

        if(obj == null){
            return false;
        }
        if(this == obj){
            return true;
        }
        if(this.getClass() != obj.getClass()){
            return false;
        }
        Order o = (Order) obj;
        if(this.orderID != o.orderID){
            return false;
        }
        if(this.clientID != o.clientID){
            return false;
        }
        if(this.getDate() != o.date){
            return false;
        }
        return true;

    }

    @Override
    public String toString() {
        return "ORDER: ORDER ID = " + orderID + ", CLIENT ID = " + clientID + ", ORDER DATE = " + date + ".\n";
    }
}
