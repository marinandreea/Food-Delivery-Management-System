package business;

import presentation.AdministratorInterface;
import presentation.ClientInterface;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.io.*;
import java.lang.management.MemoryNotificationInfo;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.chrono.ChronoLocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Class that implements the main operations that can be executed by the administrator and client
 */
public class DeliveryService extends Observable implements IDeliveryServiceProcessing, Serializable {

    private HashSet<MenuItem> menu;
    private HashMap<Order, ArrayList<MenuItem>> order;



    /**
     * Constructor that creates an object of class DeliveryService
     */
    public DeliveryService(){
        menu = new HashSet<>();
        order = new HashMap<>();

    }

    /**
     * Method that reads products from products.csv file and adds them to the menu
     */
    @Override
    public void importProducts() {
        Path P = Paths.get("C:\\Users\\Andreea\\Downloads\\products.csv");
        if(Files.exists(P)) {
            try(Stream<String> S = Files.lines(P)) {
                S.skip(1).map(s -> s.split(",")).forEach(s -> addReadProd(s[0], Float.parseFloat(s[1]), Integer.parseInt(s[2]), Integer.parseInt(s[3]), Integer.parseInt(s[4]), Integer.parseInt(s[5]), Float.parseFloat(s[6])));
            } catch(IOException E) {
                E.printStackTrace();
            }
        } else {
            System.out.println("This file doesn't exist!");
        }
    }

    /**
     * Getter for the menu with products
     *
     * @return the menu
     */
    @Override
    public HashSet<MenuItem> getFullMenu() {
        return menu;
    }

    /**
     * Method that sends a message to the regular employee interface when a new order is created
     *
     * @param string message
     */
    public void notifyEmployee(String string){

        assert string != null;

        setChanged();
        notifyObservers(string);
    }

    @Override
    public void addProduct(MenuItem item) {

        assert item != null;

        getFullMenu().add(item);
    }

    @Override
    public void addReadProd(String title, float rating, int calories, int protein, int fat, int sodium, float price) {

        assert title != null;
        assert rating >= 0;
        assert calories >= 0;
        assert protein >= 0;
        assert fat >= 0;
        assert sodium >= 0;
        assert price > 0;

        BaseProduct p = new BaseProduct(title, rating, calories, protein, fat, sodium, price);
        menu.add(p);

    }

    @Override
    public MenuItem modifyProduct(MenuItem oldItem, MenuItem newItem) {

        assert oldItem != null;
        assert newItem != null;

        oldItem.setTitle(newItem.getTitle());
        oldItem.setRating(newItem.getRating());
        oldItem.setCalories(newItem.getCalories());
        oldItem.setProtein(newItem.getProtein());
        oldItem.setFat(newItem.getFat());
        oldItem.setSodium(newItem.getSodium());
        oldItem.setPrice(newItem.getPrice());
        return oldItem;

    }

    @Override
    public void deleteProduct(MenuItem item) {

        assert item != null;

       menu.remove(item);

    }

    @Override
    public MenuItem searchProduct(String title) {

        assert title != null;

       for(MenuItem m2: getFullMenu()){
           if(m2.getTitle().equals(title)){
               return m2;
           }
       }
       return null;
    }

    @Override
    public void orderProduct(Order o, ArrayList<MenuItem> products) {

        assert o != null;
        assert products != null;

        this.order.put(o, products);
    }

    @Override
    public ArrayList<MenuItem> searchProductByTitle(String title){

        assert title != null;

       ArrayList<MenuItem> list = new ArrayList<MenuItem>();
       list = (ArrayList<MenuItem>) menu.stream().filter(v->v.getTitle().contains(title)).collect(Collectors.toList());
       return list;

    }

    @Override
    public ArrayList<MenuItem> searchProductByRating(String rating){

        assert rating != null;

        ArrayList<MenuItem> list = new ArrayList<MenuItem>();
        list = (ArrayList<MenuItem>) menu.stream().filter(v->v.getRating() == Float.parseFloat(rating)).collect(Collectors.toList());
        return list;

    }

    @Override
    public ArrayList<MenuItem> searchProductByCalories(int calories){

        assert calories >= 0;

        ArrayList<MenuItem> list;
        list = (ArrayList<MenuItem>) menu.stream()
                .filter(v->(int)v.getCalories() <= calories)
                .collect(Collectors.toList());
        return list;

    }

    @Override
    public ArrayList<MenuItem> searchProductByProtein(String protein){

        assert protein != null;

        ArrayList<MenuItem> list;
        list = (ArrayList<MenuItem>) menu.stream().filter(v->(int)v.getProtein() <= Integer.parseInt(protein)).collect(Collectors.toList());
        return list;

    }

    @Override
    public ArrayList<MenuItem> searchProductByFat(String fat){

        assert  fat != null;

        ArrayList<MenuItem> list;
        list = (ArrayList<MenuItem>) menu.stream().filter(v->(int)v.getFat() <= Integer.parseInt(fat)).collect(Collectors.toList());
        return list;

    }

    @Override
    public ArrayList<MenuItem> searchProductBySodium(String sodium){

        assert sodium != null;

        ArrayList<MenuItem> list;
        list =  (ArrayList<MenuItem>) menu.stream().filter(v->(int)v.getSodium() <= Integer.parseInt(sodium)).collect(Collectors.toList());
        return list;

    }

    @Override
    public ArrayList<MenuItem> searchProductByPrice(String price){

        assert price != null;

        ArrayList<MenuItem> list;
        list =  (ArrayList<MenuItem>) menu.stream().filter(v->(float)v.getPrice() <= Float.parseFloat(price)).collect(Collectors.toList());
        return list;

    }

    @Override
    public HashMap<Order, ArrayList<MenuItem>> getOrder(){

        return order;
    }

    @Override
    public void setOrder(HashMap<Order, ArrayList<MenuItem>> order){

        assert order != null;

        this.order = order;
    }

    @Override
    public void generateRaport1(int startTime, int endTime) throws IOException {

        assert startTime != 0;
        assert endTime != 0;

        StringBuilder stringBuilder = new StringBuilder();
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Raport1.txt")));
        stringBuilder.append("Orders ordered between " + startTime + " and " + endTime + "\n\n");

        this.getOrder().entrySet().stream().forEach(it->{
            if(it.getKey().getDate().getHour() >= startTime && it.getKey().getDate().getHour() <= endTime){
                stringBuilder.append(it.getKey() +"\n");
            }
        });
        bufferedWriter.write(stringBuilder.toString());
        bufferedWriter.close();

    }

    @Override
    public void generateRaport2(int nrOfTimes) throws IOException {

        assert nrOfTimes != 0;

        StringBuilder stringBuilder = new StringBuilder();
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Raport2.txt")));
        ArrayList<MenuItem> products = new ArrayList<>();
       for(Map.Entry<Order, ArrayList<MenuItem>> it : order.entrySet()){
           ArrayList<MenuItem> pr = it.getValue();
           for(int i = 0; i< pr.size();i++){
               products.add(pr.get(i));
               products.get(i).setCount(1);
           }
       }
        for(int i = 0; i <products.size()-1;i++){
            for(int j = i+1; j < products.size(); j++){
                if(products.get(i).getTitle().equals(products.get(j).getTitle())){
                    products.get(i).setCount(products.get(i).getCount() + 1);
                    products.remove(j);
                }
            }
        }
        List<MenuItem> prods = products.stream().filter(p->p.getCount() > nrOfTimes).collect(Collectors.toList());
        for(int i = 0;i < prods.size(); i++){
            stringBuilder.append("Product: " + prods.get(i).getTitle() + " was ordered " + prods.get(i).getCount() + " times" + "\n");
        }
        bufferedWriter.write(stringBuilder.toString());
        bufferedWriter.close();

    }

    @Override
    public void generateRaport3(int amount) throws IOException {

        assert amount > 0;

        StringBuilder stringBuilder = new StringBuilder();
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Raport3.txt")));
        List<Order> newOrderes = new ArrayList<>();
        ArrayList<MenuItem> orderedProds = new ArrayList<>();
        if(order.size() > 1){
            for(Map.Entry<Order, ArrayList<MenuItem>> it: order.entrySet()){
                ArrayList<MenuItem> products = it.getValue();
                float pr = 0;
                for(int i = 0; i < products.size(); i++){
                    pr = pr + products.get(i).getPrice();
                }
                if(pr >= amount){
                    newOrderes.add(it.getKey());
                    stringBuilder.append("Order ID: " + it.getKey().getOrderID() + " ");
                    stringBuilder.append("Price: " + pr+"\n");
                }
            }
        }
        bufferedWriter.write(stringBuilder.toString());
        bufferedWriter.close();
    }

    @Override
    public void generateRaport4(String  date) throws IOException {

        assert date != null;

        StringBuilder stringBuilder = new StringBuilder();
        BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream("Raport4.txt")));
        ArrayList<MenuItem> products = new ArrayList<>();
        Map<Order, ArrayList<MenuItem>> newOrders = new HashMap<Order, ArrayList<MenuItem>>();
        newOrders = order.entrySet().stream().filter((o->o.getKey().getDate().getDayOfMonth()==Integer.parseInt(date))).collect(Collectors.toMap(y->y.getKey(),y->y.getValue()));
        for(Map.Entry<Order, ArrayList<MenuItem>> it: newOrders.entrySet()){
            stringBuilder.append("Order id is: " + it.getKey().getOrderID()+"\n");
            ArrayList<MenuItem> prod = it.getValue();
            for(int i = 0;i < prod.size();i++){
                products.add(prod.get(i));
                products.get(i).setCount(1);
            }
        }
        for(int i = 0;i < products.size()-1;i++){
            for(int j = i+1;j < products.size();j++){
                if(products.get(i).getTitle().equals(products.get(j).getTitle())){
                    products.get(i).setCount(products.get(i).getCount() + 1);
                    products.remove(j);
                }
            }
        }
        stringBuilder.append("Products are:" + "\n");
        for(int i = 0;i < products.size();i ++){
            stringBuilder.append("Product: " + products.get(i).getTitle() + " with nr of orders: " + products.get(i).getCount() + "\n");
        }
        bufferedWriter.write(stringBuilder.toString());
        bufferedWriter.close();
    }

}
