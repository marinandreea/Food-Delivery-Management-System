package business;

import presentation.AdministratorInterface;

import javax.swing.*;
import java.awt.*;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.*;
import java.util.List;

public interface IDeliveryServiceProcessing {


    /**
     * Method that adds a new item to the menu
     *
     * @param item the product that the admin wants to add
     * @pre  item != null
     * @post menu.size = menu.size@pre + 1
     *
     */
    void addProduct(MenuItem item);

    /**
     * Method that modifies an already existing item
     *
     * @param oldItem the old item
     * @param newItem the new item
     * @pre  oldItem != null
     * @pre  newItem != null
     * @post menu.size = menu.size@pre
     * @return the modified item
     */
    MenuItem modifyProduct(MenuItem oldItem, MenuItem newItem );

    /**
     * Method that deletes a given item from the menu
     *
     * @param item item to be deleted
     * @pre  item != null
     * @post menu.size = menu.size@pre - 1
     */
    void deleteProduct(MenuItem item);

    /**
     * Method finds the product with the given title in set menu
     *
     * @param title title of a product
     * @pre title != null
     * @post menu.size = menu.size@pre
     * @return the product with the given title
     */
    MenuItem searchProduct(String title);

    /**
     * Method that adds a new order to the set of orders
     *
     * @param o order
     * @param products list of orders
     * @pre o != null
     * @pre products != null
     * @post order.size = order.size@pre + 1
     */
    void orderProduct(Order o, ArrayList<MenuItem> products);

    /**
     * Method that adds to the set of products a product read from the product.csv file
     *
     * @param title title of product
     * @param rating rating of product
     * @param calories nr calories of product
     * @param protein nr protein of product
     * @param fat nr fat of product
     * @param sodium nr sodium of product
     * @param price price of product
     * @pre title != null
     * @pre rating >= 0
     * @pre calories >= 0
     * @pre protein >= 0
     * @pre fat >= 0
     * @pre sodium >= 0
     * @pre price >= 0
     * @post menu.size = menu.size@pre + 1
     *
     */
    void addReadProd(String title, float rating, int calories, int protein, int fat, int sodium, float price );

    /**
     * Method that reads products from products.csv file and adds them to the menu
     *
     * @pre menu.size == null
     * @post menu.size = menu.size@pre + nr items from products.csv
     */
    void importProducts();

    /**
     * Getter for menu
     *
     * @return menu of products
     */
    HashSet<MenuItem> getFullMenu();

    /**
     * Method that searches the products that contain the string title in their title
     *
     * @param title title of product
     * @pre title != null
     * @return the product whose title contains the string title given as parameter
     */
    ArrayList<MenuItem> searchProductByTitle(String title);

    /**
     * Method that searches the products that has the rating equal with rating given as parameter
     *
     * @param rating rating of product
     * @pre rating != null
     * @return product with rating = rating given as parameter
     */
    ArrayList<MenuItem> searchProductByRating(String rating);

    /**
     * Method that searches the products that have the nr of calories <= calories
     *
     * @param calories nr of calories of product
     * @pre calories >= 0
     * @return product with calories <= calories given as parameter
     */
    ArrayList<MenuItem> searchProductByCalories(int calories);

    /**
     * Method that searches the products that have the nr of proteins <= protein
     *
     * @param protein nr of proteins of product
     * @pre protein != null
     * @return product with proteins <= proteins given as parameter
     */
    ArrayList<MenuItem> searchProductByProtein(String protein);

    /**
     * Method that searches the products that have the nr of fats <= fat
     *
     * @param fat nr of fats of product
     * @pre fat != null
     * @return product with fats <= fat given as parameter
     */
    ArrayList<MenuItem> searchProductByFat(String fat);

    /**
     * Method that searches the products that have the nr of sodium <= sodium
     *
     * @param sodium nr of sodium of product
     * @pre sodium != null
     * @return product with sodium <= sodium given as parameter
     */
    ArrayList<MenuItem> searchProductBySodium(String sodium);

    /**
     * Method that searches the products that have the price <= price
     *
     * @param price price of product
     * @pre price != null
     * @return product with price <= price given as parameter
     */
    ArrayList<MenuItem> searchProductByPrice(String price);

    /**
     * Getter for list of orders
     *
     * @return list of orders
     */
    HashMap<Order, ArrayList<MenuItem>> getOrder();

    /**
     * Setter for list of orders
     *
     * @param order list of orders
     * @pre order != null
     */
    void setOrder(HashMap<Order, ArrayList<MenuItem>> order);

    /**
     * Method that generates a report with the orders performed in the interval of time [startTime, endTime]
     *
     * @param startTime startTime for the interval
     * @param endTime endTime for the interval
     * @pre startTime != 0
     * @pre endTime != 0
     * @throws IOException exception
     */
    void generateRaport1(int startTime, int endTime) throws IOException;

    /**
     * Method that generates a report with the products that have been ordered more the nrOfTimes times
     *
     * @param nrOfTimes number of times
     * @pre nrOfTimes != 0
     * @throws IOException exception
     */
    void generateRaport2(int nrOfTimes) throws IOException;

    /**
     * Method that generates a report with the orders that have a price greater than amount
     *
     * @param amount amount spend by client
     * @pre amount > 0
     * @throws IOException exception
     */
    void generateRaport3(int amount) throws IOException;

    /**
     * Method that generates a report with the orders performed in the same day
     *
     * @param date date of order
     * @pre date != null
     * @throws IOException exception
     */
    void generateRaport4(String  date) throws IOException;
}
