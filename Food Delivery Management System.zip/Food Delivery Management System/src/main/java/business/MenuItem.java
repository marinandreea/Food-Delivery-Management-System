package business;

import java.io.Serializable;

public abstract class MenuItem implements Serializable {

    private String title;
    private float rating;
    private int calories;
    private int protein;
    private int fat;
    private int sodium;
    private float price;
    private int count = 1;

    public abstract float computePrice();

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public float getRating() {
        return rating;
    }

    public void setRating(float rating) {
        this.rating = rating;
    }

    public int getCalories() {
        return calories;
    }

    public void setCalories(int calories) {
        this.calories = calories;
    }

    public int getProtein() {
        return protein;
    }

    public void setProtein(int protein) {
        this.protein = protein;
    }

    public int getFat() {
        return fat;
    }

    public void setFat(int fat) {
        this.fat = fat;
    }

    public int getSodium() {
        return sodium;
    }

    public void setSodium(int sodium) {
        this.sodium = sodium;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    @Override
    public String toString(){
        return "Title: "+ getTitle() + "\n" + "Rating: " + getRating() + "\n" + "Calories: "+ getCalories()+ "\n" + "Protein: "+getProtein()+"\n"+"Fat: "+getFat()+"\n"
                + "Sodium: "+ getSodium() + "\n" + "Price: " + getPrice() + "\n";
    }


}
