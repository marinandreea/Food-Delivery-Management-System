package business;

import java.util.ArrayList;
import java.util.Objects;

public class CompositeProduct extends MenuItem{

    private String name;
    private ArrayList<MenuItem> compositeProduct;

    public CompositeProduct(String name, ArrayList<MenuItem> compositeProduct) {
        this.name = name;
        this.compositeProduct = compositeProduct;
        this.setRating(computeRating());
        this.setCalories(computeCalories());
        this.setProtein(computeProteins());
        this.setFat(computeFat());
        this.setSodium(computeSodium());
        this.setPrice(computePrice());
    }

    @Override
    public float computePrice() {

        final float[] price = {0};
        compositeProduct.forEach(product ->{
            price[0] = price[0] + product.getPrice();
        });
        return price[0];
    }

    public float computeRating() {

        final float[] rating = {0};
        compositeProduct.forEach(product ->{
            rating[0] = rating[0] + product.getRating();
        });
        return rating[0] = Float.parseFloat(String.valueOf(compositeProduct.size()));
    }

    public int computeCalories() {

        final int[] calories = {0};
        compositeProduct.forEach(product ->{
            calories[0] = calories[0] + product.getCalories();
        });
        return calories[0];
    }

    public int computeProteins() {

        final int[] proteins = {0};
        compositeProduct.forEach(product ->{
            proteins[0] = proteins[0] + product.getProtein();
        });
        return proteins[0];
    }

    public int computeFat() {

        final int[] fat = {0};
        compositeProduct.forEach(product ->{
            fat[0] = fat[0] + product.getFat();
        });
        return fat[0];
    }

    public int computeSodium() {

        final int[] sodium = {0};
        compositeProduct.forEach(product ->{
            sodium[0] = sodium[0] + product.getSodium();
        });
        return sodium[0];
    }


    @Override
    public String toString(){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Title: " + getName() + "\n" + "Composed of: ");
        for(MenuItem m : compositeProduct){
            stringBuilder.append(m.getTitle() + ", ");
        }
        return stringBuilder.toString();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
