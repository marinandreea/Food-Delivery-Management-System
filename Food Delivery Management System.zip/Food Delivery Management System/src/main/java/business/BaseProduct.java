package business;

public class BaseProduct extends MenuItem{



    private String title;
    private float rating;
    private int calories;
    private int protein;
    private int fat;
    private int sodium;
    private float price;

    public BaseProduct(String title, float rating, int calories, int protein, int fat, int sodium, float price) {
        this.title = title;
        this.rating = rating;
        this.calories = calories;
        this.protein = protein;
        this.fat = fat;
        this.sodium = sodium;
        this.price = price;

    }

    @Override
    public String getTitle() {
        return title;
    }

    @Override
    public void setTitle(String title) {
        this.title = title;
    }

    @Override
    public float getRating() {
        return rating;
    }

    @Override
    public void setRating(float rating) {
        this.rating = rating;
    }

    @Override
    public int getCalories() {
        return calories;
    }

    @Override
    public void setCalories(int calories) {
        this.calories = calories;
    }

    @Override
    public int getProtein() {
        return protein;
    }

    @Override
    public void setProtein(int protein) {
        this.protein = protein;
    }

    @Override
    public int getFat() {
        return fat;
    }

    @Override
    public void setFat(int fat) {
        this.fat = fat;
    }

    @Override
    public int getSodium() {
        return sodium;
    }

    @Override
    public void setSodium(int sodium) {
        this.sodium = sodium;
    }

    @Override
    public float getPrice() {
        return price;
    }

    @Override
    public void setPrice(float price) {
        this.price = price;
    }

    @Override
    public float computePrice() {
        return this.getPrice();
    }

    @Override
    public String toString(){
        return "Title: "+ title + ", " + "Rating: " + rating + ", " + "Calories: "+ calories+ ", " + "Protein: "+protein+", "+"Fat: "+fat+", "
                + "Sodium: "+ sodium + ", " + "Price: " + price + "\n";
    }
}
