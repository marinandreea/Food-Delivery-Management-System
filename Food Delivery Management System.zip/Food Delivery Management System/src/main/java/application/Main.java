package application;

import business.DeliveryService;
import business.MenuItem;
import presentation.*;

public class Main {

    public static void main(String[] args) {
        DeliveryService deliveryService = new DeliveryService();
        UserInterface userInterface = new UserInterface();
        AdministratorInterface administratorInterface = new AdministratorInterface();
        ClientInterface clientInterface = new ClientInterface();
        EmployeeInterface employeeInterface = new EmployeeInterface(deliveryService);
        LogInInterface logInInterface = new LogInInterface();
        MakeCompositeProdInterface makeCompositeProdInterface = new MakeCompositeProdInterface(deliveryService);

        Controller c = new Controller(userInterface, administratorInterface, logInInterface, employeeInterface, clientInterface, deliveryService, makeCompositeProdInterface);
        userInterface.setVisible(true);
    }


}
