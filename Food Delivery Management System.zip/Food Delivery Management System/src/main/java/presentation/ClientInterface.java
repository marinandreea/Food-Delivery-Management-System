package presentation;


import business.BaseProduct;
import business.MenuItem;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;

public class ClientInterface extends JFrame {
    private JButton viewProductBtn;
    private JButton searchProductBtn;
    private JButton createOrderBtn;
    private JButton backBtn;
    private JButton clearBtn;
    private JLabel titleProductLabel;
    private JTextField titleProductTxtField;
    private JLabel ratingLabel;
    private JTextField ratingTxtField;
    private JLabel caloriesLabel;
    private JTextField caloriesTxtField;
    private JLabel proteinsLabel;
    private JTextField proteinsTxtField;
    private JLabel fatLabel;
    private JTextField fatTxtField;
    private JLabel sodiumLabel;
    private JTextField sodiumTxtField;
    private JLabel priceLabel;
    private JTextField priceTxtField;
    private JTextArea logTxtArea;
    private JScrollPane logScrollPane;
    private JLabel dateLabel;
    private JTextField dateTxtField;
    private DefaultTableModel model;
    private DefaultTableModel model2;
    private JTable table;
    private JTable table2;
    private JScrollPane logScrollPane2;
    private JScrollPane logScrollPane3;



    public ClientInterface() {

        this.setTitle("Client");
        this.setSize(900, 900);
        this.setLayout((LayoutManager)null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

        //construct components
        viewProductBtn = new JButton ("Add Product");
        searchProductBtn = new JButton ("Search");
        createOrderBtn = new JButton ("Create Order");
        titleProductLabel = new JLabel("Title Product:");
        titleProductTxtField = new JTextField(5);
        ratingLabel = new JLabel("Rating:");
        ratingTxtField = new JTextField(5);
        caloriesLabel = new JLabel("Calories:");
        caloriesTxtField = new JTextField(5);
        proteinsLabel = new JLabel("Proteins:");
        proteinsTxtField = new JTextField(5);
        fatLabel = new JLabel("Fat:");
        fatTxtField = new JTextField(5);
        sodiumLabel = new JLabel("Sodium:");
        sodiumTxtField = new JTextField(5);
        priceLabel = new JLabel("Price:");
        priceTxtField = new JTextField(5);
        logTxtArea = new JTextArea();
        logScrollPane = new JScrollPane();
        backBtn = new JButton("Back");
        clearBtn = new JButton("Clear");
        dateLabel = new JLabel("Date:");
        dateTxtField = new JTextField(5);
        model = new DefaultTableModel();
        model2 = new DefaultTableModel();
        table = new JTable(model);
        table2 = new JTable();
        logScrollPane2 = new JScrollPane();
        logScrollPane3 = new JScrollPane();
        logScrollPane3.setViewportView(logTxtArea);
        logTxtArea.append("");


        //adjust size and set layout
        setPreferredSize (new Dimension (752, 457));
        setLayout (null);

        //add components
        add (viewProductBtn);
        add (searchProductBtn);
        add (createOrderBtn);
        add(backBtn);
        add(clearBtn);
        add(titleProductLabel);
        add(titleProductTxtField);
        add(ratingLabel);
        add(ratingTxtField);
        add(caloriesLabel);
        add(caloriesTxtField);
        add(proteinsLabel);
        add(proteinsTxtField);
        add(fatLabel);
        add(fatTxtField);
        add(sodiumLabel);
        add(sodiumTxtField);
        add(priceLabel);
        add(priceTxtField);
        add(backBtn);
        add(clearBtn);
        add(logScrollPane);
        add(dateLabel);
        add(dateTxtField);
        add(logScrollPane2);
        add(logScrollPane3);

        //set component bounds (only needed by Absolute Positioning)
        viewProductBtn.setBounds (410, 30, 115, 30);
        searchProductBtn.setBounds (550, 30, 115, 30);
        createOrderBtn.setBounds (690, 30, 115, 30);
        clearBtn.setBounds(410,100,115,30);
        backBtn.setBounds(550,100,115,30);
        titleProductLabel.setBounds(10, 30, 85, 25);
        titleProductTxtField.setBounds(90, 30, 165, 25);
        ratingLabel.setBounds(10, 80, 75, 25);
        ratingTxtField.setBounds(90, 80, 165, 25);
        caloriesLabel.setBounds(10, 115, 80, 25);
        caloriesTxtField.setBounds(90, 115, 165, 25);
        proteinsLabel.setBounds(10, 150, 80, 25);
        proteinsTxtField.setBounds(90, 150, 165, 25);
        fatLabel.setBounds(10, 190, 80, 25);
        fatTxtField.setBounds(90, 185, 165, 25);
        sodiumLabel.setBounds(10, 225, 80, 25);
        sodiumTxtField.setBounds(90, 225, 165, 25);
        priceLabel.setBounds(10, 265, 80, 25);
        priceTxtField.setBounds(90, 265, 165, 25);
        dateLabel.setBounds(300, 265, 165, 25);
        dateTxtField.setBounds(350, 265, 165, 25);
        logScrollPane.setBounds(10, 300, 870, 300);
        logScrollPane2.setBounds(40,610,400,150);
        logScrollPane3.setBounds(470,610,400,150);

        model.addColumn("Title");
        model.addColumn("Rating");
        model.addColumn("Calories");
        model.addColumn("Protein");
        model.addColumn("Fat");
        model.addColumn("Sodium");
        model.addColumn("Price");

    }
    public void updateLogsClient(String updateText){
        logTxtArea.append(updateText+"\n");
        JScrollBar myScrollBar = logScrollPane3.getVerticalScrollBar();
        myScrollBar.setValue(myScrollBar.getMinimum());
    }


    public JTextField getTitleProductTxtField() {
        return titleProductTxtField;
    }

    public JTextField getRatingTxtField() {
        return ratingTxtField;
    }


    public JTextField getCaloriesTxtField() {
        return caloriesTxtField;
    }


    public JTextField getProteinsTxtField() {
        return proteinsTxtField;
    }


    public JTextField getFatTxtField() {
        return fatTxtField;
    }


    public JTextField getSodiumTxtField() {
        return sodiumTxtField;
    }


    public JTextField getPriceTxtField() {
        return priceTxtField;
    }


    public JTextField getDateTxtField() {
        return dateTxtField;
    }


    public JTable getTable() {
        return table;
    }

    public DefaultTableModel getModel() {
        return model;
    }

    public JScrollPane getLogScrollPane() {
        return logScrollPane;
    }

    public JTable getTable2() {
        return table2;
    }

    public DefaultTableModel getModel2() {
        return model2;
    }

    public void createTable(ArrayList<MenuItem> products) throws IOException {
        add(logScrollPane2);
        logScrollPane2.setViewportView(table2);
        model2 = new DefaultTableModel();

        model2.addColumn("Title");
        model2.addColumn("Rating");
        model2.addColumn("Calories");
        model2.addColumn("Protein");
        model2.addColumn("Fat");
        model2.addColumn("Sodium");
        model2.addColumn("Price");
        //model.setRowCount(0);
        Object[] row = new Object[7];
        for (MenuItem b : products) {
            row[0] = b.getTitle();
            row[1] = b.getRating();
            row[2] = b.getCalories();
            row[3] = b.getProtein();
            row[4] = b.getFat();
            row[5] = b.getSodium();
            row[6] = b.getPrice();

            model2.addRow(row);
        }
        table2.setModel(model2);
    }

    public void addBackBtn(ActionListener listener){
        backBtn.addActionListener(listener);
    }
    public void addClearBtn(ActionListener listener){
        clearBtn.addActionListener(listener);
    }
    public void addViewProductsBtn(ActionListener listener){
        viewProductBtn.addActionListener(listener);
    }
    public void addSearchProductBtn(ActionListener listener){
        searchProductBtn.addActionListener(listener);
    }
    public void addCreateOrderBtn(ActionListener listener){
        createOrderBtn.addActionListener(listener);
    }


}