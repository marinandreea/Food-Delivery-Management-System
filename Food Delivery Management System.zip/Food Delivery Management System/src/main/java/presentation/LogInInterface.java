package presentation;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class LogInInterface extends JFrame {
    private JLabel logInLabel;
    private JLabel usernameLabel;
    private JTextField usernameTxtField;
    private JLabel passwordLabel;
    private JPasswordField passwordTxtField;
    private JButton logInBtn;

    public LogInInterface() {

        this.setTitle("Log In");
        this.setSize(900, 900);
        this.setLayout((LayoutManager)null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

        //construct components
        logInLabel = new JLabel ("PLEASE LOG IN:");
        usernameLabel = new JLabel ("Username:");
        usernameTxtField = new JTextField (5);
        passwordLabel = new JLabel ("Password:");
        passwordTxtField = new JPasswordField (5);
        logInBtn = new JButton ("Log In");


        //adjust size and set layout
        setPreferredSize (new Dimension (752, 457));
        setLayout (null);



        //add components
        add (logInLabel);
        add (usernameLabel);
        add (usernameTxtField);
        add (passwordLabel);
        add (passwordTxtField);
        add (logInBtn);

        //set component bounds (only needed by Absolute Positioning)
        logInLabel.setBounds (280, 55, 145, 45);
        usernameLabel.setBounds (120, 145, 80, 30);
        usernameTxtField.setBounds (200, 150, 175, 30);
        passwordLabel.setBounds (120, 220, 80, 30);
        passwordTxtField.setBounds (200, 220, 175, 30);
        logInBtn.setBounds (310, 300, 100, 25);
    }

    public String getUsernameTxtField() {
        return usernameTxtField.getText();
    }

    public String getPasswordTxtField() {
        return new String(passwordTxtField.getPassword());
    }



    public void addConfirmButtonListener(ActionListener listener) {
        logInBtn.addActionListener(listener);
    }

    public boolean credentialsAdministrator(String username, String password){
        return "admin".equals(username) && "12345".equals(password);
    }
    public boolean credentialsEmployee(String username, String password){
        return "employee".equals(username) && "135".equals(password);
    }

    public boolean credentialsClient(String username, String password){
        return "client".equals(username) && "246".equals(password);
    }


}