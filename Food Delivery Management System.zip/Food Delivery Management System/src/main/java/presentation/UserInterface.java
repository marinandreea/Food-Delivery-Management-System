package presentation;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

public class UserInterface extends JFrame {
    private JLabel selectUserLabel;
    private JButton administratorBtn;
    private JButton regularEmployeeBtn;
    private JButton clientBtn;

    public UserInterface() {

        this.setTitle("Food Delivery Management System");
        this.setSize(900, 900);
        this.setLayout((LayoutManager)null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

        //construct components
        selectUserLabel = new JLabel ("Please select the user:");
        administratorBtn = new JButton ("Administrator");
        regularEmployeeBtn = new JButton ("Regular Employee");
        clientBtn = new JButton ("Client");

        //adjust size and set layout
        setPreferredSize (new Dimension (752, 457));
        setLayout (null);

        //add components
        add (selectUserLabel);
        add (administratorBtn);
        add (regularEmployeeBtn);
        add (clientBtn);

        //set component bounds (only needed by Absolute Positioning)
        selectUserLabel.setBounds (270, 50, 140, 40);
        administratorBtn.setBounds (270, 120, 140, 35);
        regularEmployeeBtn.setBounds (270, 195, 140, 35);
        clientBtn.setBounds (270, 270, 140, 35);
    }

    public void addListenerAdministratorBtn(ActionListener e) {
        this.administratorBtn.addActionListener(e);
    }

    public void addListenerRegularEmployeeBtn(ActionListener e) {
        this.regularEmployeeBtn.addActionListener(e);
    }

    public void addListenerClientBtn(ActionListener e) {
        this.clientBtn.addActionListener(e);
    }



}
