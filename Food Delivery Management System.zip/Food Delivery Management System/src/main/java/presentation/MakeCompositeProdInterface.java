package presentation;

import business.BaseProduct;
import business.DeliveryService;

import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.DefaultTableModel;

public class MakeCompositeProdInterface extends JFrame {
    private JLabel label;

    private JTextArea txtArea;
    private JButton clearBtn;
    private JButton backBtn;
    private JButton addProductBtn;
    private JButton createProductBtn;
    private AdministratorInterface administratorInterface;
    DeliveryService deliveryService;
    private JLabel titleLabel;
    private JTextField titleTxtField;
    private JScrollPane logScrollPane;
    private JScrollPane logScrollPane2;
    private DefaultTableModel model;
    private JTable table;

    public MakeCompositeProdInterface(DeliveryService deliveryService) {

        this.setTitle("Make Composite Products");
        this.setSize(900, 900);
        this.setLayout((LayoutManager) null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);
        this.deliveryService = deliveryService;

        //construct components
        label = new JLabel ("Please choose maximum 4 products to create the composite product:");

        txtArea = new JTextArea (5, 5);
        clearBtn = new JButton ("Clear");
        backBtn = new JButton ("Back");
        createProductBtn = new JButton("Create Product");
        addProductBtn = new JButton("Add Product");
        titleLabel = new JLabel ("Title:");
        titleTxtField = new JTextField (5);
        logScrollPane = new JScrollPane();
        logScrollPane2 = new JScrollPane();
        model = new DefaultTableModel();
        table = new JTable(model);

        //adjust size and set layout
        setPreferredSize (new Dimension (752, 457));
        setLayout (null);

        //add components
        add (label);

        add (txtArea);
        add (clearBtn);
        add (backBtn);
        add(createProductBtn);
        add (titleLabel);
        add (titleTxtField);
        add(logScrollPane);
        add(addProductBtn);
        add(logScrollPane2);

        //set component bounds (only needed by Absolute Positioning)
        label.setBounds (35, 0, 395, 35);
        logScrollPane2.setBounds(40,85,400,150);
        logScrollPane2.setViewportView(txtArea);
        txtArea.setText("");

        logScrollPane.setBounds (35, 255, 700, 300);
        model.addColumn("Title");
        model.addColumn("Rating");
        model.addColumn("Calories");
        model.addColumn("Protein");
        model.addColumn("Fat");
        model.addColumn("Sodium");
        model.addColumn("Price");
        //logScrollPane.setViewportView(txtArea);
        clearBtn.setBounds (565, 30, 100, 25);
        backBtn.setBounds (565, 65, 100, 25);
        addProductBtn.setBounds(565,100,150,25);
        createProductBtn.setBounds(565,135,150,25);
        titleLabel.setBounds (40, 45, 100, 25);
        titleTxtField.setBounds (150, 40, 260, 30);



    }

    public void addBackBtn(ActionListener listener){
        backBtn.addActionListener(listener);
    }
    public void addClearBtn(ActionListener listener){
        clearBtn.addActionListener(listener);
    }
    public void addCreateProductBtn(ActionListener listener){
        createProductBtn.addActionListener(listener);
    }
    public void addAddProductBtn(ActionListener listener){addProductBtn.addActionListener(listener);}




    public JTextField getTitleTxtField() {
        return titleTxtField;
    }

    public JTable getTable() {
        return table;
    }

    public DefaultTableModel getModel() {
        return model;
    }

    public JScrollPane getLogScrollPane() {
        return logScrollPane;
    }

    public void updateLogs2(String updateText){
        txtArea.append(updateText+"\n");
        JScrollBar myScrollBar = logScrollPane2.getVerticalScrollBar();
        myScrollBar.setValue(myScrollBar.getMinimum());
    }
}