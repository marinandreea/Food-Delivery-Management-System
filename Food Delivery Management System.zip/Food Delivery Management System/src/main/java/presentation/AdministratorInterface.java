package presentation;

import business.BaseProduct;
import business.MenuItem;

import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class AdministratorInterface extends JFrame {
    private JButton createProductBtn;
    private JButton addProductBtn;
    private JButton deleteProductBtn;
    private JButton modifyProductBtn;
    private JButton importProductsBtn;
    private JLabel titleProductLabel;
    private JTextField titleProductTxtField;
    private JLabel ratingLabel;
    private JTextField ratingTxtField;
    private JLabel caloriesLabel;
    private JTextField caloriesTxtField;
    private JLabel proteinsLabel;
    private JTextField proteinsTxtField;
    private JLabel fatLabel;
    private JTextField fatTxtField;
    private JLabel sodiumLabel;
    private JTextField sodiumTxtField;
    private JLabel priceLabel;
    private JTextField priceTxtField;
    private JTextArea logTxtArea;
    private JScrollPane logScrollPane;
    private JButton backBtn;
    private JButton clearBtn;
    private DefaultTableModel model;
    private JTable table;
    private JLabel startHourLabel;
    private JLabel endHourLabel;
    private JTextField startHourTxtField;
    private JTextField endHourTxtField;
    private JButton raport1Button;
    private JLabel nrOfTimesLabel;
    private JTextField nrOfTimesTxtField;
    private JButton raport2Button;
    private JLabel amountLabel;
    private JTextField amountTxtField;
    private JButton raport3Button;
    private JLabel dayLabel;
    private JTextField dayTxtField;
    private JButton raport4Button;

    private List<BaseProduct> products;

    public AdministratorInterface() {

        this.setTitle("Administrator");
        this.setSize(900, 900);
        this.setLayout((LayoutManager) null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);


        //construct components
        createProductBtn = new JButton("Create");
        addProductBtn = new JButton("Add");
        deleteProductBtn = new JButton("Delete");
        modifyProductBtn = new JButton("Modify");
        importProductsBtn = new JButton("Import set of products");
        titleProductLabel = new JLabel("Title Product:");
        titleProductTxtField = new JTextField(5);
        ratingLabel = new JLabel("Rating:");
        ratingTxtField = new JTextField(5);
        caloriesLabel = new JLabel("Calories:");
        caloriesTxtField = new JTextField(5);
        proteinsLabel = new JLabel("Proteins:");
        proteinsTxtField = new JTextField(5);
        fatLabel = new JLabel("Fat:");
        fatTxtField = new JTextField(5);
        sodiumLabel = new JLabel("Sodium:");
        sodiumTxtField = new JTextField(5);
        priceLabel = new JLabel("Price:");
        priceTxtField = new JTextField(5);
        logTxtArea = new JTextArea();
        logScrollPane = new JScrollPane();
        backBtn = new JButton("Back");
        clearBtn = new JButton("Clear");
         model = new DefaultTableModel();
         table = new JTable(model);
        startHourLabel = new JLabel ("Start hour");
        endHourLabel = new JLabel ("End hour");
        startHourTxtField = new JTextField (5);
        endHourTxtField = new JTextField (5);
        raport1Button = new JButton ("Raport 1");
        nrOfTimesLabel = new JLabel ("Nr of times");
        nrOfTimesTxtField = new JTextField (5);
        raport2Button = new JButton ("Raport 2");
        amountLabel = new JLabel ("Amount");
        amountTxtField = new JTextField (5);
        raport3Button = new JButton ("Raport 3");
        dayLabel = new JLabel ("Day");
        dayTxtField = new JTextField (5);
        raport4Button = new JButton ("Raport 4");

        //adjust size and set layout
        setPreferredSize(new Dimension(752, 457));
        setLayout(null);

        //add components
        add(createProductBtn);
        add(addProductBtn);
        add(deleteProductBtn);
        add(modifyProductBtn);
        add(importProductsBtn);
        add(titleProductLabel);
        add(titleProductTxtField);
        add(ratingLabel);
        add(ratingTxtField);
        add(caloriesLabel);
        add(caloriesTxtField);
        add(proteinsLabel);
        add(proteinsTxtField);
        add(fatLabel);
        add(fatTxtField);
        add(sodiumLabel);
        add(sodiumTxtField);
        add(priceLabel);
        add(priceTxtField);
        add(logScrollPane);
        add(backBtn);
        add(clearBtn);
        add (startHourLabel);
        add (endHourLabel);
        add (startHourTxtField);
        add (endHourTxtField);
        add (raport1Button);
        add (nrOfTimesLabel);
        add (nrOfTimesTxtField);
        add (raport2Button);
        add (amountLabel);
        add (amountTxtField);
        add (raport3Button);
        add (dayLabel);
        add (dayTxtField);
        add (raport4Button);


        //set component bounds (only needed by Absolute Positioning)
        createProductBtn.setBounds(410, 30, 100, 25);
        addProductBtn.setBounds(550, 30, 100, 25);
        deleteProductBtn.setBounds(410, 95, 100, 25);
        modifyProductBtn.setBounds(550, 95, 100, 25);
        importProductsBtn.setBounds(410, 160, 165, 25);
        titleProductLabel.setBounds(10, 30, 85, 25);
        titleProductTxtField.setBounds(90, 30, 165, 25);
        ratingLabel.setBounds(10, 80, 75, 25);
        ratingTxtField.setBounds(90, 80, 165, 25);
        caloriesLabel.setBounds(10, 115, 80, 25);
        caloriesTxtField.setBounds(90, 115, 165, 25);
        proteinsLabel.setBounds(10, 150, 80, 25);
        proteinsTxtField.setBounds(90, 150, 165, 25);
        fatLabel.setBounds(10, 190, 80, 25);
        fatTxtField.setBounds(90, 185, 165, 25);
        sodiumLabel.setBounds(10, 225, 80, 25);
        sodiumTxtField.setBounds(90, 225, 165, 25);
        priceLabel.setBounds(10, 265, 80, 25);
        priceTxtField.setBounds(90, 265, 165, 25);
        logScrollPane.setBounds(10, 300, 870, 400);
        model.addColumn("Title");
        model.addColumn("Rating");
        model.addColumn("Calories");
        model.addColumn("Protein");
        model.addColumn("Fat");
        model.addColumn("Sodium");
        model.addColumn("Price");
        backBtn.setBounds(690,30,100,25);
        clearBtn.setBounds(690,95,100,25);
        startHourLabel.setBounds (15, 710, 60, 30);
        endHourLabel.setBounds (15, 740, 70, 25);
        startHourTxtField.setBounds (75, 710, 40, 25);
        endHourTxtField.setBounds (75, 740, 40, 25);
        raport1Button.setBounds (120, 715, 95, 30);
        nrOfTimesLabel.setBounds (240, 710, 70, 30);
        nrOfTimesTxtField.setBounds (305, 710, 55, 25);
        raport2Button.setBounds (240, 740, 100, 25);
        amountLabel.setBounds (395, 710, 75, 25);
        amountTxtField.setBounds (455, 710, 40, 25);
        raport3Button.setBounds (400, 740, 100, 25);
        dayLabel.setBounds (530, 710, 35, 30);
        dayTxtField.setBounds (560, 710, 35, 30);
        raport4Button.setBounds (530, 740, 100, 25);
    }

    public void addCreateProductBtn(ActionListener listener){
        createProductBtn.addActionListener(listener);
    }
    public void addAddProductBtn(ActionListener listener){
        addProductBtn.addActionListener(listener);
    }
    public void addDeleteProductBtn(ActionListener listener){
        deleteProductBtn.addActionListener(listener);
    }
    public void addModifyProductBtn(ActionListener listener){
        modifyProductBtn.addActionListener(listener);
    }
    public void addImportProductsBtn(ActionListener listener){
        importProductsBtn.addActionListener(listener);
    }
    public void addBackBtn(ActionListener listener){
        backBtn.addActionListener(listener);
    }
    public void addClearBtn(ActionListener listener){
        clearBtn.addActionListener(listener);
    }
    public void addRaport1Button(ActionListener listener) {raport1Button.addActionListener(listener);}
    public void addRaport2Button(ActionListener listener) {raport2Button.addActionListener(listener);}
    public void addRaport3Button(ActionListener listener) {raport3Button.addActionListener(listener);}
    public void addRaport4Button(ActionListener listener) {raport4Button.addActionListener(listener);}

    public void updateLogs(String updateText){
        logTxtArea.append(updateText+"\n");
        JScrollBar myScrollBar = logScrollPane.getVerticalScrollBar();
        myScrollBar.setValue(myScrollBar.getMinimum());
    }

    public List<MenuItem> createList(HashSet<MenuItem> list){
        List<MenuItem> l = new ArrayList<>();
        l.addAll(list);
        return l;
    }

    public DefaultTableModel createModel(){
        DefaultTableModel m = new DefaultTableModel();
        return m;
    }


    public JTextField getTitleProductTxtField() {
        return titleProductTxtField;
    }

    public JTextField getRatingTxtField() {
        return ratingTxtField;
    }

    public JTextField getCaloriesTxtField() {
        return caloriesTxtField;
    }

    public JTextField getProteinsTxtField() {
        return proteinsTxtField;
    }

    public JTextField getFatTxtField() {
        return fatTxtField;
    }

    public JTextField getSodiumTxtField() {
        return sodiumTxtField;
    }

    public JTextField getPriceTxtField() {
        return priceTxtField;
    }

    public JTextField getStartHourTxtField() {
        return startHourTxtField;
    }

    public JTextField getEndHourTxtField() {
        return endHourTxtField;
    }

    public JTextField getNrOfTimesTxtField() {
        return nrOfTimesTxtField;
    }

    public JTextField getAmountTxtField() {
        return amountTxtField;
    }

    public JTextField getDayTxtField() {
        return dayTxtField;
    }

    public BaseProduct getProd(){

        String title = this.getTitleProductTxtField().getText();
        Float rating = Float.parseFloat(this.getRatingTxtField().getText());
        int calories = Integer.parseInt(this.getCaloriesTxtField().getText());
        int proteins = Integer.parseInt(this.getProteinsTxtField().getText());
        int fat = Integer.parseInt(this.getFatTxtField().getText());
        int sodium = Integer.parseInt(this.getSodiumTxtField().getText());
        float price = Float.parseFloat(this.getPriceTxtField().getText());
        BaseProduct prod = new BaseProduct(title, rating, calories, proteins, fat, sodium, price);
        return prod;
    }

    public JTable getTable() {
        return table;
    }

    public DefaultTableModel getModel() {
        return model;
    }

    public JScrollPane getLogScrollPane() {
        return logScrollPane;
    }

}
