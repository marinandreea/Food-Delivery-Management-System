package presentation;

import business.DeliveryService;

import java.awt.*;
import java.awt.event.*;
import java.util.Observable;
import java.util.Observer;
import javax.swing.*;
import javax.swing.event.*;

public class EmployeeInterface extends JFrame implements Observer {

    private JTextArea txtArea;
    private DeliveryService deliveryService;
    private JScrollPane scrollPane;

    public JTextArea getTxtArea() {
        return txtArea;
    }

    public EmployeeInterface(DeliveryService deliveryService) {

        this.deliveryService = deliveryService;
        deliveryService.addObserver(this);

        this.setTitle("Regular Employee");
        this.setSize(900, 900);
        this.setLayout((LayoutManager)null);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.setVisible(true);

        txtArea = new JTextArea();
        scrollPane = new JScrollPane();
        add(scrollPane);
        scrollPane.setBounds(10, 30, 600, 300);
        scrollPane.setViewportView(txtArea);
        txtArea.setText("");

        //construct components

        //adjust size and set layout
        setPreferredSize (new Dimension (752, 457));
        setLayout (null);


    }


    @Override
    public void update(Observable o, Object arg) {

       // this.setVisible(true);
        txtArea.append(arg.toString());
        JScrollBar myScrollBar = scrollPane.getVerticalScrollBar();
        myScrollBar.setValue(myScrollBar.getMinimum());
    }
}