package presentation;

import business.*;

import javax.management.MalformedObjectNameException;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

import data.FileWriter;
import data.Serializator;


public class Controller {

    UserInterface userInterface;
    AdministratorInterface administratorInterface;
    LogInInterface logInInterface;
    EmployeeInterface employeeInterface;
    ClientInterface clientInterface;
    DeliveryService deliveryService;
    MakeCompositeProdInterface makeCompositeProdInterface;
    StringBuilder stringBuilder = new StringBuilder();
    ArrayList<MenuItem> list = new ArrayList<MenuItem>();
    ArrayList<MenuItem> listOrders = new ArrayList<MenuItem>();
    Serializator serializator = new Serializator();
    int i=0;
    private static int contor = 0;
    private static int ctr = 0;
    private static int contor2 = 0;
    private static int contor3 = 0;

    public Controller(UserInterface userInterface, AdministratorInterface administratorInterface, LogInInterface logInInterface, EmployeeInterface employeeInterface, ClientInterface clientInterface, DeliveryService deliveryService, MakeCompositeProdInterface makeCompositeProdInterface) {
        this.userInterface = userInterface;
        this.administratorInterface = administratorInterface;
        this.logInInterface = logInInterface;
        this.employeeInterface = employeeInterface;
        this.clientInterface = clientInterface;
       // this.deliveryService = Serializator.deserialize();
        this.deliveryService = deliveryService;
        this.makeCompositeProdInterface = makeCompositeProdInterface;
         initializeButtons();

    }

    public void initializeButtons(){

        userInterface.addListenerAdministratorBtn(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userInterface.setVisible(false);
                logInInterface.setVisible(true);

                initializeButtonLogIn();

            }
        });

        userInterface.addListenerRegularEmployeeBtn(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userInterface.setVisible(false);
                logInInterface.setVisible(true);
                initializeButtonLogInEmployee();


            }
        });

        userInterface.addListenerClientBtn(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userInterface.setVisible(false);
                logInInterface.setVisible(true);
                initializeButtonLogInClient();

            }
        });


    }

    public void initializeButtonLogIn(){

        logInInterface.addConfirmButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String introducedUsername = logInInterface.getUsernameTxtField();
                String introducedPassword = logInInterface.getPasswordTxtField();
                if(introducedUsername.contains("a")){
                if(logInInterface.credentialsAdministrator(introducedUsername,introducedPassword)){
                    logInInterface.setVisible(false);
                    administratorInterface.setVisible(true);
                    initializeButtonsAdministrator();
                }else {
                    JOptionPane.showMessageDialog(null, "Username or password incorrect!\nPlease try again!");
                }}
            }
        });
    }

    public void initializeButtonLogInClient(){
        logInInterface.addConfirmButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String introducedUsername = logInInterface.getUsernameTxtField();
                String introducedPassword = logInInterface.getPasswordTxtField();
                if(introducedUsername.contains("c")){
                if(logInInterface.credentialsClient(introducedUsername,introducedPassword)){
                    logInInterface.setVisible(false);
                    clientInterface.setVisible(true);
                    initializeClientButtons();
                }else {
                    JOptionPane.showMessageDialog(null, "Username or password incorrect!\nPlease try again!");
                }}
            }
        });
    }

    public void initializeButtonLogInEmployee(){
        logInInterface.addConfirmButtonListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String introducedUsername = logInInterface.getUsernameTxtField();
                String introducedPassword = logInInterface.getPasswordTxtField();
                if(introducedUsername.contains("e")){
                if(logInInterface.credentialsEmployee(introducedUsername,introducedPassword)){
                    logInInterface.setVisible(false);
                    employeeInterface.setVisible(true);
                }else {
                    JOptionPane.showMessageDialog(null, "Username or password incorrect!\nPlease try again!");
                }
            }}
        });
    }

    public void initializeButtonsAdministrator(){

     administratorInterface.addImportProductsBtn(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
             deliveryService.importProducts();

             administratorInterface.getLogScrollPane().setViewportView(administratorInterface.getTable());
             deliveryService.getFullMenu().stream().forEach(s->administratorInterface.getModel().addRow(new Object[]{s.getTitle(),s.getRating(),s.getCalories(),s.getProtein(),s.getFat(),s.getSodium(),s.getPrice()}));
             administratorInterface.getTable().setModel(administratorInterface.getModel());

             makeCompositeProdInterface.getLogScrollPane().setViewportView(makeCompositeProdInterface.getTable());
             deliveryService.getFullMenu().stream().forEach(s->makeCompositeProdInterface.getModel().addRow(new Object[]{s.getTitle(),s.getRating(),s.getCalories(),s.getProtein(),s.getFat(),s.getSodium(),s.getPrice()}));
             makeCompositeProdInterface.getTable().setModel(makeCompositeProdInterface.getModel());

             clientInterface.getLogScrollPane().setViewportView(clientInterface.getTable());
             deliveryService.getFullMenu().stream().forEach(s->clientInterface.getModel().addRow(new Object[]{s.getTitle(),s.getRating(),s.getCalories(),s.getProtein(),s.getFat(),s.getSodium(),s.getPrice()}));
             clientInterface.getTable().setModel(clientInterface.getModel());


             System.out.println(deliveryService.getFullMenu().size());
         }
     });

     administratorInterface.addAddProductBtn(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
             BaseProduct p = administratorInterface.getProd();

             deliveryService.addProduct(p);

             deliveryService.getFullMenu().stream().forEach(s->administratorInterface.getModel().addRow(new Object[]{s.getTitle(),s.getRating(),s.getCalories(),s.getProtein(),s.getFat(),s.getSodium(),s.getPrice()}));
             administratorInterface.getModel().addRow(new Object[]{p.getTitle(),p.getRating(),p.getCalories(),p.getProtein(),p.getFat(),p.getSodium(),p.getPrice()});
             administratorInterface.getTable().setModel(administratorInterface.getModel());

             makeCompositeProdInterface.getLogScrollPane().setViewportView(makeCompositeProdInterface.getTable());
             deliveryService.getFullMenu().stream().forEach(s->makeCompositeProdInterface.getModel().addRow(new Object[]{s.getTitle(),s.getRating(),s.getCalories(),s.getProtein(),s.getFat(),s.getSodium(),s.getPrice()}));
             makeCompositeProdInterface.getModel().addRow(new Object[]{p.getTitle(),p.getRating(),p.getCalories(),p.getProtein(),p.getFat(),p.getSodium(),p.getPrice()});
             makeCompositeProdInterface.getTable().setModel(makeCompositeProdInterface.getModel());

             clientInterface.getLogScrollPane().setViewportView(clientInterface.getTable());
             deliveryService.getFullMenu().stream().forEach(s->clientInterface.getModel().addRow(new Object[]{s.getTitle(),s.getRating(),s.getCalories(),s.getProtein(),s.getFat(),s.getSodium(),s.getPrice()}));
             clientInterface.getModel().addRow(new Object[]{p.getTitle(),p.getRating(),p.getCalories(),p.getProtein(),p.getFat(),p.getSodium(),p.getPrice()});
             clientInterface.getTable().setModel(clientInterface.getModel());

             Serializator.serialize(deliveryService);

             //System.out.println(deliveryService.getFullMenu().size());


         }
     });

     administratorInterface.addDeleteProductBtn(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
             String titlu = administratorInterface.getModel().getValueAt(administratorInterface.getTable().getSelectedRow(),0).toString();
             MenuItem item = deliveryService.searchProduct(titlu);

             deliveryService.deleteProduct(item);

             clientInterface.getModel().removeRow(administratorInterface.getTable().getSelectedRow());
             makeCompositeProdInterface.getModel().removeRow(administratorInterface.getTable().getSelectedRow());
             administratorInterface.getModel().removeRow(administratorInterface.getTable().getSelectedRow());


             Serializator.serialize(deliveryService);


            }
     });

     administratorInterface.addModifyProductBtn(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
             String title = administratorInterface.getTitleProductTxtField().getText();
             MenuItem oldItem = deliveryService.searchProduct(title);
             MenuItem newItem = administratorInterface.getProd();
             MenuItem item = deliveryService.modifyProduct(oldItem,newItem);

             administratorInterface.getModel().setValueAt(item.getTitle(),administratorInterface.getTable().getSelectedRow(),0);
             administratorInterface.getModel().setValueAt(item.getRating(),administratorInterface.getTable().getSelectedRow(),1);
             administratorInterface.getModel().setValueAt(item.getCalories(),administratorInterface.getTable().getSelectedRow(),2);
             administratorInterface.getModel().setValueAt(item.getProtein(),administratorInterface.getTable().getSelectedRow(),3);
             administratorInterface.getModel().setValueAt(item.getFat(),administratorInterface.getTable().getSelectedRow(),4);
             administratorInterface.getModel().setValueAt(item.getSodium(),administratorInterface.getTable().getSelectedRow(),5);
             administratorInterface.getModel().setValueAt(item.getPrice(),administratorInterface.getTable().getSelectedRow(),6);
             administratorInterface.getTable().setModel(administratorInterface.getModel());

             makeCompositeProdInterface.getModel().setValueAt(item.getTitle(),administratorInterface.getTable().getSelectedRow(),0);
             makeCompositeProdInterface.getModel().setValueAt(item.getRating(),administratorInterface.getTable().getSelectedRow(),1);
             makeCompositeProdInterface.getModel().setValueAt(item.getCalories(),administratorInterface.getTable().getSelectedRow(),2);
             makeCompositeProdInterface.getModel().setValueAt(item.getProtein(),administratorInterface.getTable().getSelectedRow(),3);
             makeCompositeProdInterface.getModel().setValueAt(item.getFat(),administratorInterface.getTable().getSelectedRow(),4);
             makeCompositeProdInterface.getModel().setValueAt(item.getSodium(),administratorInterface.getTable().getSelectedRow(),5);
             makeCompositeProdInterface.getModel().setValueAt(item.getPrice(),administratorInterface.getTable().getSelectedRow(),6);
             makeCompositeProdInterface.getTable().setModel(makeCompositeProdInterface.getModel());

             clientInterface.getModel().setValueAt(item.getTitle(),administratorInterface.getTable().getSelectedRow(),0);
             clientInterface.getModel().setValueAt(item.getRating(),administratorInterface.getTable().getSelectedRow(),1);
             clientInterface.getModel().setValueAt(item.getCalories(),administratorInterface.getTable().getSelectedRow(),2);
             clientInterface.getModel().setValueAt(item.getProtein(),administratorInterface.getTable().getSelectedRow(),3);
             clientInterface.getModel().setValueAt(item.getFat(),administratorInterface.getTable().getSelectedRow(),4);
             clientInterface.getModel().setValueAt(item.getSodium(),administratorInterface.getTable().getSelectedRow(),5);
             clientInterface.getModel().setValueAt(item.getPrice(),administratorInterface.getTable().getSelectedRow(),6);
             clientInterface.getTable().setModel(makeCompositeProdInterface.getModel());

             Serializator.serialize(deliveryService);



            }
        });

        administratorInterface.addClearBtn(new ActionListener() {
            /**
             * @param e click on the clear button
             *
             * The method clears all the text fields
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                administratorInterface.getTitleProductTxtField().setText("");
                administratorInterface.getRatingTxtField().setText("");
                administratorInterface.getCaloriesTxtField().setText("");
                administratorInterface.getFatTxtField().setText("");
                administratorInterface.getSodiumTxtField().setText("");
                administratorInterface.getProteinsTxtField().setText("");
                administratorInterface.getPriceTxtField().setText("");
            }
        });

        administratorInterface.addBackBtn(new ActionListener() {
            /**
             * @param e click on the back button
             *
             * The method takes the user back to the main window (userInterface)
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                administratorInterface.setVisible(false);
                userInterface.setVisible(true);
            }
        });

     administratorInterface.addCreateProductBtn(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {

             administratorInterface.setVisible(false);
             makeCompositeProdInterface.setVisible(true);
             initializeCompositeProdInterface();

            }
        });

     administratorInterface.addRaport1Button(new ActionListener() {
         @Override
         public void actionPerformed(ActionEvent e) {
             String startHour = administratorInterface.getStartHourTxtField().getText();
             String endHour = administratorInterface.getEndHourTxtField().getText();
             try {
                 deliveryService.generateRaport1(Integer.parseInt(startHour), Integer.parseInt(endHour));
             } catch (IOException ex) {
                 ex.printStackTrace();
             }
         }
     });

        administratorInterface.addRaport2Button(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nrOfTimes = administratorInterface.getNrOfTimesTxtField().getText();
                try {
                    deliveryService.generateRaport2(Integer.parseInt(nrOfTimes));
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        administratorInterface.addRaport3Button(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //String nrOfTimes = administratorInterface.getNrOfTimesOrderedTxtField().getText();
                String amount = administratorInterface.getAmountTxtField().getText();
                try {
                    deliveryService.generateRaport3(Integer.parseInt(amount));
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

        administratorInterface.addRaport4Button(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String date = administratorInterface.getDayTxtField().getText();
                try {
                    deliveryService.generateRaport4(date);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }
        });

    }

    public void initializeCompositeProdInterface(){

        makeCompositeProdInterface.addAddProductBtn(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                String titlu1 = makeCompositeProdInterface.getModel().getValueAt(makeCompositeProdInterface.getTable().getSelectedRow(),0).toString();
                float rating1 = (float)makeCompositeProdInterface.getModel().getValueAt(makeCompositeProdInterface.getTable().getSelectedRow(),1);
                int calories1 = (int)makeCompositeProdInterface.getModel().getValueAt(makeCompositeProdInterface.getTable().getSelectedRow(),2);
                int proteins1 = (int)makeCompositeProdInterface.getModel().getValueAt(makeCompositeProdInterface.getTable().getSelectedRow(),3);
                int fat1 = (int)makeCompositeProdInterface.getModel().getValueAt(makeCompositeProdInterface.getTable().getSelectedRow(),4);
                int sodium1 = (int)makeCompositeProdInterface.getModel().getValueAt(makeCompositeProdInterface.getTable().getSelectedRow(),5);
                float price1 = (float)makeCompositeProdInterface.getModel().getValueAt(makeCompositeProdInterface.getTable().getSelectedRow(),6);


                BaseProduct p = new BaseProduct(titlu1,rating1,calories1,proteins1,fat1,sodium1,price1);
                list.add(p);


            }
        });

        makeCompositeProdInterface.addCreateProductBtn(new ActionListener() {
                    /**
                     * @param e click on the clear button
                     *
                     * The method clears all the text fields
                     */
                    @Override
                    public void actionPerformed(ActionEvent e) {

                        String title = makeCompositeProdInterface.getTitleTxtField().getText();
                        stringBuilder.append(title + ":"+"\n");
                        for(MenuItem m:list){
                            stringBuilder.append(m.getTitle()+"\n");
                        }
                        makeCompositeProdInterface.updateLogs2(stringBuilder.toString());
                        stringBuilder.delete(0,stringBuilder.length());
                        CompositeProduct prod = new CompositeProduct(title, list);
                        BaseProduct pr =  new BaseProduct(title, prod.computeRating(), prod.computeCalories(), prod.computeProteins(), prod.computeFat(), prod.computeSodium(), prod.computePrice());
                        deliveryService.addProduct(pr);
                        clientInterface.getModel().addRow(new Object[]{prod.getName(),prod.computeRating(),prod.computeCalories(),prod.computeProteins(),prod.computeFat(),prod.computeSodium(),prod.computePrice()});
                        makeCompositeProdInterface.getModel().addRow(new Object[]{prod.getName(),prod.computeRating(),prod.computeCalories(),prod.computeProteins(),prod.computeFat(),prod.computeSodium(),prod.computePrice()});
                        administratorInterface.getModel().addRow(new Object[]{prod.getName(),prod.computeRating(),prod.computeCalories(),prod.computeProteins(),prod.computeFat(),prod.computeSodium(),prod.computePrice()});
                        list = new ArrayList<MenuItem>();
                        Serializator.serialize(deliveryService);

                    }
                });



        makeCompositeProdInterface.addClearBtn(new ActionListener() {
            /**
             * @param e click on the clear button
             *
             * The method clears all the text fields
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                makeCompositeProdInterface.getTitleTxtField().setText("");

            }
        });

        makeCompositeProdInterface.addBackBtn(new ActionListener() {
            /**
             * @param e click on the back button
             *
             * The method takes the user back to the main window (userInterface)
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                makeCompositeProdInterface.setVisible(false);
                administratorInterface.setVisible(true);
            }
        });



    }

    public void initializeClientButtons(){

        clientInterface.addSearchProductBtn(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                contor++;
             String title = clientInterface.getTitleProductTxtField().getText();
                System.out.println(title);
             String rating = clientInterface.getRatingTxtField().getText();
             String calories = clientInterface.getCaloriesTxtField().getText();
             String protein = clientInterface.getProteinsTxtField().getText();
             String fat = clientInterface.getFatTxtField().getText();
             String sodium = clientInterface.getSodiumTxtField().getText();
             String price = clientInterface.getPriceTxtField().getText();
             ArrayList<MenuItem> list = new ArrayList<>();
             ArrayList<BaseProduct> list2 = null;
             StringBuilder s = new StringBuilder();

             if(!title.equals("-")){
                 list = deliveryService.searchProductByTitle(title);
             }
             if(!rating.equals("-")){
                 list = deliveryService.searchProductByRating(rating);
             }
             if(!calories.equals("-")){
                 list = deliveryService.searchProductByCalories(Integer.parseInt(calories));
             }
             if(!protein.equals("-")){
                 list = deliveryService.searchProductByProtein(protein);
             }
             if(!fat.equals("-")){
                 list = deliveryService.searchProductByFat(fat);
             }
             if(!sodium.equals("-")){
                 list = deliveryService.searchProductBySodium(sodium);
             }
             if(!price.equals("-")){
                 list = deliveryService.searchProductByPrice(price);
             }

                System.out.println(list.size());




                 try {
                     if(list.size() == 0){
                         clientInterface.updateLogsClient("Product not found!");
                     }else{
                     clientInterface.createTable(list);
                     list = new ArrayList<>();}
                 } catch (IOException ex) {
                     ex.printStackTrace();
                 }



            }
        });

        clientInterface.addBackBtn(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clientInterface.setVisible(false);
                userInterface.setVisible(true);
            }
        });

        clientInterface.addClearBtn(new ActionListener() {
            /**
             * @param e click on the clear button
             *
             * The method clears all the text fields
             */
            @Override
            public void actionPerformed(ActionEvent e) {
                clientInterface.getTitleProductTxtField().setText("");
                clientInterface.getRatingTxtField().setText("");
                clientInterface.getCaloriesTxtField().setText("");
                clientInterface.getFatTxtField().setText("");
                clientInterface.getSodiumTxtField().setText("");
                clientInterface.getProteinsTxtField().setText("");
                clientInterface.getPriceTxtField().setText("");
            }
        });

        clientInterface.addViewProductsBtn(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                contor3++;


                String title2 = clientInterface.getModel2().getValueAt(clientInterface.getTable2().getSelectedRow(),0).toString();
                String rating2 = null, calories2 = null, protein2 = null, fat2 = null, sodium2 = null, price2 = null;

                        rating2 = clientInterface.getModel2().getValueAt(clientInterface.getTable2().getSelectedRow(),1).toString();
                        calories2 = clientInterface.getModel2().getValueAt(clientInterface.getTable2().getSelectedRow(),2).toString();
                        protein2 = clientInterface.getModel2().getValueAt(clientInterface.getTable2().getSelectedRow(),3).toString();
                        fat2 = clientInterface.getModel2().getValueAt(clientInterface.getTable2().getSelectedRow(),4).toString();
                        sodium2= clientInterface.getModel2().getValueAt(clientInterface.getTable2().getSelectedRow(),5).toString();
                        price2 = clientInterface.getModel2().getValueAt(clientInterface.getTable2().getSelectedRow(),6).toString();

                    BaseProduct pr = new BaseProduct(title2, Float.parseFloat(rating2), Integer.parseInt(calories2), Integer.parseInt(protein2), Integer.parseInt(fat2), Integer.parseInt(sodium2), Float.parseFloat(price2));

                        listOrders.add(pr);}





        });

        clientInterface.addCreateOrderBtn(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                System.out.println("size " + listOrders.size());
                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyy, HH");
                LocalDateTime localDateTime = LocalDateTime.parse(clientInterface.getDateTxtField().getText(), formatter);
                ctr = ctr + 1; contor2++;
                Random rand1 = new Random();
                Random rand2 = new Random();
                int orderId = rand1.nextInt(150);
                int clientId = rand2.nextInt(100);
                Order o = new Order(orderId,clientId, localDateTime);

                System.out.println(ctr);


                FileWriter fileWriter = new FileWriter();
                try {
                    fileWriter.writeInFile(o, listOrders);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
                deliveryService.orderProduct(o, listOrders);
                listOrders = new ArrayList<MenuItem>();

                StringBuilder ss = new StringBuilder();
                ss.append("\n\nNEW order created" + "\n");
                ss.append("Order ID: " + o.getOrderID() +"\n");
                ss.append("Date: " + o.getDate() + "\n");
                ss.append("Order items:" + "\n");
                HashMap<Order, ArrayList<MenuItem>> myMap = deliveryService.getOrder();
                ArrayList<MenuItem> list = myMap.get(o);
                Iterator<MenuItem> it = list.iterator();
                while(it.hasNext()){
                    ss.append(it.next().toString());
                }
                stringBuilder.append("\n\n");
                deliveryService.notifyEmployee(ss.toString());

                }

        });

    }
}
